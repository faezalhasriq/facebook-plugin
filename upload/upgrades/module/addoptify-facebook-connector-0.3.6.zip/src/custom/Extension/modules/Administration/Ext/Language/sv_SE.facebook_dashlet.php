<?php

$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_LINK_NAME'] = 'Konfiguera inställningar';
$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_LINK_DESCRIPTION'] = 'Konfiguera globala inställningar för Facebook dashleten';
$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_SECTION_HEADER'] = 'Facebook dashlet inställningar';
$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_SECTION_DESCRIPTION'] = ' ';
