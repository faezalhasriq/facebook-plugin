<?php
$dictionary['Case']['fields']['facebook_post_id'] = array(
    'name' => 'facebook_post_id',
    'vname' => 'LBL_FACEBOOK_POST_ID',
    'type' => 'varchar',
    'audited' => false,
    'required' => false,
    'duplicate_on_record_copy' => "no",
);
