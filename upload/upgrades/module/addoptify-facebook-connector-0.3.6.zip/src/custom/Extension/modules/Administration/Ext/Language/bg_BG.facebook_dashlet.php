<?php

$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_LINK_NAME'] = 'Configure settings';
$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_LINK_DESCRIPTION'] = 'Configure global settings for the Facebook dashlet';
$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_SECTION_HEADER'] = 'Facebook dashlet settings';
$mod_strings['LBL_FACEBOOK_DASHLET_SETTINGS_SECTION_DESCRIPTION'] = ' ';
