<?php
require_once('include/api/SugarApi.php');

/**
 * Facebook-related Cases api calls
 *
 * @author Oskar Hellgren <oskar.hellgren@dri-nordic.com>
 */
class CustomCasesFacebookApi extends SugarApi
{

    public function registerApiRest()
    {
        return array(
            'getCasesByFacebookIds' => array(
                'reqType' => 'POST',
                'path' => array('Cases', 'get_cases_by_facebook_ids'),
                'pathVars' => array('', ''),
                'method' => 'getExistingCasesByIds',
                'shortHelp' => 'Get ids of existing cases related to facebook posts',
                'longHelp' => '',
            ),
            'getExistingCasesByIds' => array(
                'reqType' => 'POST',
                'path' => array('Cases', 'get_facebook_id_by_case'),
                'pathVars' => array('', ''),
                'method' => 'getFbIdsByCase',
                'shortHelp' => 'Get ids of existing cases related to facebook posts',
                'longHelp' => '',
            ),
        );
    }

    /**
     * Get ids of existing cases related to facebook posts
     *
     * @param ServiceBase $api
     * @param array $args
     * @return array
     */
    public function getExistingCasesByIds($api, $args)
    {
        $data = array();

        if (isset($args['ids']) && !empty($args['ids'])) {
            $db = DBManagerFactory::getInstance();

            foreach ($args['ids'] as $fb_id) {
                $fb_id   = $db->quote($fb_id); //Clean string
                $query   = "SELECT id FROM cases WHERE facebook_post_id = '$fb_id' AND deleted = 0 ";
                $case_id = $db->getOne($query);

                if (!empty($case_id)) {
                    $data[$fb_id] = $db->getOne($query);
                }
            }
        }

        return $data;
    }

    /**
     * Get ids of existing cases related to facebook posts
     *
     * @param ServiceBase $api
     * @param array $args
     * @return array
     */
    public function getFbIdsByCase($api, $args)
    {
        $data = array(
            'success' => true,
            'error' => '',
            'id' => '',
        );

        try {
            if (isset($args['id']) && !empty($args['id'])) {
                $db = DBManagerFactory::getInstance();

                $case_id = $db->quote($args['id']); //Clean string
                $query   = "SELECT facebook_post_id AS id FROM cases WHERE id = '$case_id' AND deleted = 0 ";
                $result  = $db->query($query);

                while ($row = $db->fetchByAssoc($result)) {
                    $data['id'] = $row["id"];
                }
            }
        } catch (Exception $exc) {
            $data['success'] = false;
            $data['error']   = $exc->getMessage();
        }
        return $data;
    }
}