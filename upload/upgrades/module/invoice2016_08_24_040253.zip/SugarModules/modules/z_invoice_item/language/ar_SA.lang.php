<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'الفرق',
  'LBL_TEAMS' => 'الفرق',
  'LBL_TEAM_ID' => 'معرّف الفريق',
  'LBL_ASSIGNED_TO_ID' => 'معرّف المستخدم المعين',
  'LBL_ASSIGNED_TO_NAME' => 'تعيين إلى',
  'LBL_TAGS_LINK' => 'العلامات',
  'LBL_TAGS' => 'العلامات',
  'LBL_ID' => 'المعرّف',
  'LBL_DATE_ENTERED' => 'تاريخ الإنشاء',
  'LBL_DATE_MODIFIED' => 'تاريخ التعديل',
  'LBL_MODIFIED' => 'تم التعديل بواسطة',
  'LBL_MODIFIED_ID' => 'تم التعديل بواسطة المعرّف',
  'LBL_MODIFIED_NAME' => 'تم التعديل بواسطة الاسم',
  'LBL_CREATED' => 'تم الإنشاء بواسطة',
  'LBL_CREATED_ID' => 'تم الإنشاء بواسطة المعرّف',
  'LBL_DOC_OWNER' => 'مالك المستند',
  'LBL_USER_FAVORITES' => 'المستخدمون الذي يفضلون',
  'LBL_DESCRIPTION' => 'الوصف',
  'LBL_DELETED' => 'تم الحذف',
  'LBL_NAME' => 'الاسم',
  'LBL_CREATED_USER' => 'تم الإنشاء بواسطة مستخدم',
  'LBL_MODIFIED_USER' => 'تم التعديل بواسطة مستخدم',
  'LBL_LIST_NAME' => 'الاسم',
  'LBL_EDIT_BUTTON' => 'تحرير',
  'LBL_REMOVE' => 'إزالة',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'تم التعديل بواسطة الاسم',
  'LBL_LIST_FORM_TITLE' => 'Invoice Item القائمة',
  'LBL_MODULE_NAME' => 'Invoice Item',
  'LBL_MODULE_TITLE' => 'Invoice Item',
  'LBL_MODULE_NAME_SINGULAR' => 'Invoice Item',
  'LBL_HOMEPAGE_TITLE' => 'الخاص بي Invoice Item',
  'LNK_NEW_RECORD' => 'إنشاء Invoice Item',
  'LNK_LIST' => 'عرض Invoice Item',
  'LNK_IMPORT_Z_ITEM' => 'Import Invoice Item',
  'LBL_SEARCH_FORM_TITLE' => 'بحث Invoice Item',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'عرض السجل',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'سير النشاط الكلي',
  'LBL_Z_ITEM_SUBPANEL_TITLE' => 'Invoice Item',
  'LBL_NEW_FORM_TITLE' => 'جديد Invoice Item',
  'LNK_IMPORT_VCARD' => 'Import Invoice Item vCard',
  'LBL_IMPORT' => 'Import Invoice Item',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Invoice Item record by importing a vCard from your file system.',
  'LBL_ITEM_DESC' => 'Item Desc',
  'LBL_ITEM_AMT' => 'Item Amount',
  'LBL_ITEM_GST' => 'Item GST',
  'LBL_ITEM_GST_AMT' => 'Item GST Amt',
  'LBL_ITEM_AMT_INCL_GST' => 'Item Amount Including GST',
  'LNK_IMPORT_Z_INVOICE_ITEM' => 'Import Invoice Item',
  'LBL_Z_INVOICE_ITEM_SUBPANEL_TITLE' => 'Invoice Item',
);