<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'קבוצות',
  'LBL_TEAMS' => 'קבוצות',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'מזהה משתמש מוקצה',
  'LBL_ASSIGNED_TO_NAME' => 'משתמש',
  'LBL_TAGS_LINK' => 'תגיות',
  'LBL_TAGS' => 'תגיות',
  'LBL_ID' => 'מזהה',
  'LBL_DATE_ENTERED' => 'נוצר בתאריך',
  'LBL_DATE_MODIFIED' => 'שונה בתאריך',
  'LBL_MODIFIED' => 'נערך על ידי',
  'LBL_MODIFIED_ID' => 'שונה על ידי Id',
  'LBL_MODIFIED_NAME' => 'שונה על ידי ששמו',
  'LBL_CREATED' => 'נוצר על ידי',
  'LBL_CREATED_ID' => 'נוצר על ידי Id',
  'LBL_DOC_OWNER' => 'בעל המסמך',
  'LBL_USER_FAVORITES' => 'משתמשים שמעדיפים',
  'LBL_DESCRIPTION' => 'תיאור',
  'LBL_DELETED' => 'נמחק',
  'LBL_NAME' => 'שם',
  'LBL_CREATED_USER' => 'נוצר על ידי משתמש',
  'LBL_MODIFIED_USER' => 'שונה על ידי משתמש',
  'LBL_LIST_NAME' => 'שם',
  'LBL_EDIT_BUTTON' => 'ערוך',
  'LBL_REMOVE' => 'הסר',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'שונה על ידי משתמש',
  'LBL_LIST_FORM_TITLE' => 'Invoice Item List',
  'LBL_MODULE_NAME' => 'Invoice Item',
  'LBL_MODULE_TITLE' => 'Invoice Item',
  'LBL_MODULE_NAME_SINGULAR' => 'Invoice Item',
  'LBL_HOMEPAGE_TITLE' => 'שלי Invoice Item',
  'LNK_NEW_RECORD' => 'צור Invoice Item',
  'LNK_LIST' => 'View Invoice Item',
  'LNK_IMPORT_Z_ITEM' => 'Import Invoice Item',
  'LBL_SEARCH_FORM_TITLE' => 'Search Invoice Item',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_Z_ITEM_SUBPANEL_TITLE' => 'Invoice Item',
  'LBL_NEW_FORM_TITLE' => 'חדש Invoice Item',
  'LNK_IMPORT_VCARD' => 'Import Invoice Item vCard',
  'LBL_IMPORT' => 'Import Invoice Item',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Invoice Item record by importing a vCard from your file system.',
  'LBL_ITEM_DESC' => 'Item Desc',
  'LBL_ITEM_AMT' => 'Item Amount',
  'LBL_ITEM_GST' => 'Item GST',
  'LBL_ITEM_GST_AMT' => 'Item GST Amt',
  'LBL_ITEM_AMT_INCL_GST' => 'Item Amount Including GST',
  'LNK_IMPORT_Z_INVOICE_ITEM' => 'Import Invoice Item',
  'LBL_Z_INVOICE_ITEM_SUBPANEL_TITLE' => 'Invoice Item',
);