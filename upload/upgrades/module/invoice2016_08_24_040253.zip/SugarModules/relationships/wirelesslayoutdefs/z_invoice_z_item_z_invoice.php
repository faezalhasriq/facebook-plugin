<?php
 // created: 2016-08-22 09:03:56
$layout_defs["z_invoice"]["subpanel_setup"]['z_invoice_z_item'] = array (
  'order' => 100,
  'module' => 'z_item',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_ITEM_TITLE',
  'get_subpanel_data' => 'z_invoice_z_item',
);
