<?php
// created: 2016-08-22 09:03:56
$dictionary["z_invoice"]["fields"]["z_invoice_z_item"] = array (
  'name' => 'z_invoice_z_item',
  'type' => 'link',
  'relationship' => 'z_invoice_z_item',
  'source' => 'non-db',
  'module' => 'z_item',
  'bean_name' => false,
  'vname' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_INVOICE_TITLE',
  'id_name' => 'z_invoice_z_itemz_invoice_ida',
  'link-type' => 'many',
  'side' => 'left',
);
