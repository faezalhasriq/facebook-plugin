<?php
// created: 2016-08-22 08:35:50
$viewdefs['z_invoice']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'z_invoice_z_item',
  ),
);

$viewdefs['z_invoice']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'z_invoice_z_item',
  ),
);

$viewdefs['z_invoice']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'z_invoice_z_item',
  ),
);

$viewdefs['z_invoice']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'z_invoice_z_item',
  ),
);

$viewdefs['z_invoice']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_Z_INVOICE_Z_ITEM_FROM_Z_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'z_invoice_z_item',
  ),
);