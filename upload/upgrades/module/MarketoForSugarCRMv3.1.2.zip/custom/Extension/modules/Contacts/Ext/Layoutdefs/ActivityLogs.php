<?php
/*
* Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
* pursuant to the terms of the End User License Agreement available at
* http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
*/
require_once("include/externalAPI/Marketo/MarketoFactory.php");
if (MarketoFactory::getInstance(false)->isEnabled()) {
    $layout_defs["Contacts"]["subpanel_setup"]["marketo"] = array(
        'order' => 100,
        'module' => 'ActivityLogs',
        'subpanel_name' => 'default',
        'sort_order' => 'desc',
        'sort_by' => 'date_modified',
        'title_key' => 'LBL_ACTIVITY_LOGS',
        'get_subpanel_data' => 'function:getActivityLogs',
        'function_parameters' => array(
            'import_function_file' => 'custom/include/marketo/MarketoUtils.php',
        ),
        'set_subpanel_data' => 'activity_logs',
        'top_buttons' => array(),
    );
}