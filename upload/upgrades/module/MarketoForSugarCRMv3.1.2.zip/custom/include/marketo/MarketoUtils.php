<?php
/*
* Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
* pursuant to the terms of the End User License Agreement available at
* http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
*/
require_once("include/externalAPI/Marketo/MarketoFactory.php");

function getActivityLogs()
{
    global $app;

    if (MarketoFactory::getInstance(false)->isEnabled()) {
        $bean = $app->controller->bean;
        if (empty($bean->id)) {
            return;
        }

        if (!empty($bean->mkto_id)) {
            $sql = "select max(date_modified) as date_modified from activity_logs where mkto_id = '$bean->mkto_id' and deleted = 0";
            $result = $bean->db->query(
                $sql,
                true,
                "Error obtaining information from ActivityLogs for $bean->mkto_id"
            );

            $row = $bean->db->fetchByAssoc($result);
            if ($row != null) {
                $date = $row['date_modified'];
            }

            $mkto = MarketoFactory::getInstance(true);
            $startPosition = new StreamPosition();
            if (!empty($date)) {
                $dt = new DateTime($date, new DateTimeZone('GMT'));
                $startPosition->oldestCreatedAt = $dt->format(DateTime::W3C);
            } else {
                $dt = new DateTime('now');
                $dt->sub(new DateInterval('P1Y'));
                $startPosition->oldestCreatedAt = $dt->format(DATE_W3C);
            }

            $doPage = true;
            while ($doPage) {
                $successGetLeadChanges = $mkto->getLeadChanges(
                    new ParamsGetLeadChanges($startPosition, new ActivityTypeFilter(new ArrayOfActivityType($mkto->getProperty(
                        'filters'
                    ))), 1000, new LeadKeySelector(LeadKeyRef::IDNUM, ArrayOfString::withStringItem(
                        array($bean->mkto_id)
                    )))
                );

                if ($successGetLeadChanges->result->returnCount > 0) {
                    if ($successGetLeadChanges->result->returnCount == 1) {
                        $successGetLeadChanges->result->leadChangeRecordList->leadChangeRecord = array($successGetLeadChanges->result->leadChangeRecordList->leadChangeRecord);
                    }

                    foreach ($successGetLeadChanges->result->leadChangeRecordList->leadChangeRecord as $leadChangeRecord) {
                        $mkto->synchronizeActivityLogsToSugarCRM($leadChangeRecord);
                        $args['leadChangeRecord'][$leadChangeRecord->id] = $leadChangeRecord->id;
                    }

                    $startPosition = $successGetLeadChanges->result->newStartPosition;
                } else {
                    $doPage = false;
                }
            }
        }
    }

    return "select * from activity_logs where deleted = 0 and mkto_id = '$bean->mkto_id'";
}