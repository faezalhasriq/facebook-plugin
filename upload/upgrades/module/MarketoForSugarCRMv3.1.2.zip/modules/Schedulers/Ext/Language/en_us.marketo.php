<?php
/*
* Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
* pursuant to the terms of the End User License Agreement available at
* http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
*/

$mod_strings['LBL_MARKETOSYNC'] = 'Check Marketo&reg; for changes to Leads';
$mod_strings['LBL_MARKETOACTIVITYLOGSYNC'] = 'Check for Marketo&reg; for updates to Activity Logs';
$mod_strings['LBL_MARKETOPURGEOLDJOBS'] = 'Delete old jobs from Marketo&reg; table';
