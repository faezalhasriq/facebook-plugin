<?php
/*
* Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
* pursuant to the terms of the End User License Agreement available at
* http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
*/

$mod_strings['LBL_MRKTO2_FISCAL_YEAR'] = 'Fiscal Year';
$mod_strings['LBL_MRKTO2_FISCAL_QUARTER'] = 'Fiscal Quarter';
$mod_strings['LBL_MRKTO2_IS_WON'] = 'Is Won';
$mod_strings['LBL_MRKTO2_IS_CLOSED'] = 'Is Closed';
$mod_strings['LBL_MRKTO2_FORECASTCATEGORYNAME'] = 'Forecast Category';
$mod_strings['LBL_MRKTO2_EXPECTED_REVENUE'] = 'Expected Revenue';
$mod_strings['LBL_MKTO_SYNC'] = 'Sync to Marketo&reg;';
$mod_strings['LBL_MKTO_ID'] = 'Marketo ID';