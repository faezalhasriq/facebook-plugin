<?php
/*
* Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
* pursuant to the terms of the End User License Agreement available at
* http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
*/
$connector_strings = array(
    'LBL_EXTERNALCREATEDDATE' => 'SFDC Created Date',
    'LBL_ID' => 'Id',
    'LBL_ISPRIMARY' => 'Is Primary',
    'LBL_OPPORTUNITYID' => 'Opportunity Id',
    'LBL_PERSONID' => 'Contact Id',
    'LBL_ROLE' => 'Role',
);