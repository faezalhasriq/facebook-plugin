<?php
/*
 * Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
 * pursuant to the terms of the End User License Agreement available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
 */

require_once('modules/Administration/QuickRepairAndRebuild.php');
require_once 'modules/Connectors/connectors/sources/ext/soap/marketo/MarketoHelper.php';

function post_install()
{

    $connectors['ext_soap_marketo'] = array(
        'id' => 'ext_soap_marketo',
        'name' => 'Marketo',
        'enabled' => true,
        'directory' => 'modules/Connectors/connectors/sources/ext/soap/marketo',
        'eapm' => false,
        'modules' => array(
            0 => 'Accounts',
            1 => 'Contacts',
            2 => 'Leads',
            3 => 'Users',
        ),
    );

    /* Requires SugarCRM 6.2 */
    if (!ConnectorUtils::saveConnectors($connectors, 'custom/modules/Connectors/metadata/connectors.php')) {
        $GLOBALS['log']->fatal('Cannot write file custom/modules/Connectors/metadata/connectors.php');
    }

    require_once('include/connectors/utils/ConnectorUtils.php');
    require_once('modules/Connectors/controller.php');

    $modules_sources = ConnectorUtils::getDisplayConfig();
    if (!is_array($modules_sources)) {
        $modules_sources = (array)$modules_sources;
    }

    $modules = array('Accounts', 'Contacts', 'Leads', 'Users');
    $source_id = 'ext_soap_marketo';

    foreach ($modules as $module) {
        $modules_sources[$module][$source_id] = $source_id;
    }

    foreach ($modules_sources as $module => $def) {
        foreach ($def as $key => $value) {
            $a[] = array($key, $module);
        }
    }
    asort($a);
    $display_values = "";
    foreach ($a as $item) {
        $display_values .= implode(':', $item) . ',';
    }

    $_REQUEST['display_values'] = substr($display_values, 0, -1);
    $_REQUEST['display_sources'] = 'ext_soap_marketo';
    $_REQUEST['from_unit_test'] = true;

    $controller = new ConnectorsController();
    $controller->action_SaveModifyDisplay();

    $mappingForUpdate = MarketoHelper::getMappingForUpdateOnInstall();
    $mappingForUpdateRequest = array();
    if ($mappingForUpdate) {
        foreach ($mappingForUpdate['beans'] as $module => $map) {
            foreach ($map as $key => $value) {
                $mappingForUpdateRequest[] = $source_id . ':' . $module . ':' . $key . '=' . $value;
            }
        }
        if ($mappingForUpdateRequest) {
            $_REQUEST['from_unit_test'] = true;
            $_REQUEST['mapping_values'] = implode(',', $mappingForUpdateRequest);
            $_REQUEST['mapping_sources'] = $source_id;
            $controller->action_SaveModifyMapping();
        }
    }

    $sugarConfigurator = new \Configurator();
    if (!isset($sugarConfigurator->config['marketo_purge_interval'])) {
        $sugarConfigurator->config['marketo_purge_interval'] = '5';
    }
    $sugarConfigurator->config['marketo_has_mapping'] = false;
    $sugarConfigurator->handleOverride();

    /* REPAIR THE DATABASE TO ADD OUR NEW INDEXES */
    $repair = new RepairAndClear();
    $repair->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), true, false);

    echo translate(
        'LBL_MARKETO_QUICK_REPAIR_AND_REBUILD',
        'Administration'
    );

    if ($mappingForUpdateRequest) {
        echo '<script>
		if (typeof window.app !== "undefined") {
            window.app.alert.show(\'marketo_mapping_alert\', 
                {
                    level: \'warning\',
                    title: \'' . translate('LBL_MARKETO_MAPPING_UPDATED', 'Administration') . '\'
                }); 		
            }
		</script>';
    }
}
