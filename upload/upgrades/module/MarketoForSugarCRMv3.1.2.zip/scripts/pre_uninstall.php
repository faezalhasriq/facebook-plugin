<?php
/*
 * Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
 * pursuant to the terms of the End User License Agreement available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
 */

require_once('include/connectors/utils/ConnectorUtils.php');
require_once 'modules/Connectors/connectors/sources/ext/soap/marketo/MarketoHelper.php';
require_once('modules/Connectors/controller.php');
function pre_uninstall()
{
    MarketoHelper::validateDeleting();

    // clear module sources
    $modules_sources = ConnectorUtils::getDisplayConfig();
    if (!is_array($modules_sources)) {
        $modules_sources = (array)$modules_sources;
    }

    $modules = array('Accounts', 'Contacts', 'Leads', 'Users');
    $source_id = 'ext_soap_marketo';

    foreach ($modules as $module) {
        if (isset($modules_sources[$module][$source_id])) {
            unset($modules_sources[$module][$source_id]);
        }
    }

    foreach ($modules_sources as $module => $def) {
        foreach ($def as $key => $value) {
            $a[] = array($key, $module);
        }
    }
    asort($a);

    $display_values = "";
    foreach ($a as $item) {
        $display_values .= implode(':', $item) . ',';
    }

    $_REQUEST['display_values'] = substr($display_values, 0, -1);
    $_REQUEST['display_sources'] = 'ext_soap_marketo';
    $_REQUEST['from_unit_test'] = true;

    $controller = new ConnectorsController();
    $controller->action_SaveModifyDisplay();

    // clear custom connector settings
    $connectors = ConnectorUtils::getConnectors();
    if (isset($connectors['ext_soap_marketo'])) {
        unset($connectors['ext_soap_marketo']);
    }

    if (!ConnectorUtils::saveConnectors($connectors, 'custom/modules/Connectors/metadata/connectors.php')) {
        $GLOBALS['log']->fatal('Cannot write file custom/modules/Connectors/metadata/connectors.php');
    }

    require_once('modules/Administration/QuickRepairAndRebuild.php');

}