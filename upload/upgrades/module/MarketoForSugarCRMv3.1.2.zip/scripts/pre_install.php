<?php
/*
* Copyright (c) 2014-2015 SugarCRM Inc.  This product is licensed by SugarCRM
* pursuant to the terms of the End User License Agreement available at
* http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/10_Marketo/
*/

/*
 * The Marketo Connector requires a PHP version 5.3.0 or higher and several other
 * components to work. Double check that they exist before proceeding!
 */
function pre_install()
{
    if (version_compare(phpversion(), '5.3.0') < 0) {
        $msg = 'Minimum PHP version required is 5.3.0.  You are using PHP version  ' . phpversion();
        sugar_die($msg);
    }
    if (!class_exists('SoapClient')) {
        sugar_die('Soap is not installed in your environment! Please add Soap to your PHP configuration');
    }

    if (!function_exists('hash_hmac')) {
        sugar_die(
            '<strong>hash_hmac</strong> is not installed in your environment! Please add <strong>hash_hmac</strong> to your PHP configuration'
        );
    }
}